=== Klipse ===
Contributors: Yehonathan Sharvit
Tags: code, snippets, interactive, javsascript
License: GPLv3
License URI: http://www.gnu.org/licenses/gpl-3.0.html

The Klipse plugin allows you to embed interactive code snippets in your articles.

== Description ==

The Klipse plugin allows you to embed interactive code snippets in your articles.

== Installation ==

1. Upload the `klipse` folder to the `/wp-content/plugins` directory
2. Activate the plugin through the 'Plugins' menu in WordPress


